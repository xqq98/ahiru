package com.webservice.ahiru.entity;

import java.util.List;

public class Bu {
    private List<String> bu;

    public List<String> getBu() {
        return bu;
    }

    public void setBu(List<String> bu) {
        this.bu = bu;
    }
}
