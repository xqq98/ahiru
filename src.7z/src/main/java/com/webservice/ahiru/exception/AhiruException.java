package com.webservice.ahiru.exception;

public class AhiruException extends RuntimeException {
    public AhiruException(String message){
        super(message);
    }
}
