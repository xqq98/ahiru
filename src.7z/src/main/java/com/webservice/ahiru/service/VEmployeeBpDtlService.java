package com.webservice.ahiru.service;

import com.baomidou.mybatisplus.service.IService;
import com.webservice.ahiru.entity.VEmployeeBpDtl;

public interface VEmployeeBpDtlService extends IService<VEmployeeBpDtl> {
}
