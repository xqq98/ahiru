package com.webservice.ahiru.service.impl;


import com.baomidou.mybatisplus.service.impl.ServiceImpl;


import com.webservice.ahiru.entity.VEmployeeBpDtl;

import com.webservice.ahiru.mapper.VEmployeeBpDtlMapper;
import com.webservice.ahiru.service.VEmployeeBpDtlService;


public class VEmployeeBpDtlServiceImpl extends ServiceImpl<VEmployeeBpDtlMapper, VEmployeeBpDtl> implements VEmployeeBpDtlService {
}
