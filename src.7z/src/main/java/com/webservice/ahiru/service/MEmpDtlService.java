package com.webservice.ahiru.service;

import com.baomidou.mybatisplus.service.IService;
import com.webservice.ahiru.entity.MEmpDtl;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wanghao
 * @since 2020-12-31
 */
//Service层业务接口类编写
public interface MEmpDtlService extends IService<MEmpDtl> {

}
