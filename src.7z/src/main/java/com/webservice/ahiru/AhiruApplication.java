package com.webservice.ahiru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AhiruApplication {

    public static void main(String[] args) {
        SpringApplication.run(AhiruApplication.class, args);
    }

}
